#ifndef __RENDER_W_H__
#define __RENDER_W_H__

#include <QWidget>
#include <QPainter>

#include "grid.h"
#include "vec-field.h"
#include "scalar-field.h"


class RenderW : public QWidget{
	Q_OBJECT

	public:
		static const unsigned int RAND_POINT_COUNT = 1000;

		RenderW(QWidget *parent = 0): v(0) {}
		// ~RenderW();

		void setVecField(VecField2f* vec_field) { if (vec_field == 0) return; v = vec_field; pixel_grid.setArea(v->grid().min(), v->grid().max()); }

		void setScalarField(ScalarField2f* scalar_field) { if (scalar_field == 0) return; s = scalar_field; }


	protected:
		void paintEvent(QPaintEvent *event){
			if (v == 0)
				return;

			QPainter painter(this);
			painter.setRenderHints(QPainter::Antialiasing, true);
			
			QImage map(width(), height(), QImage::Format_RGB32);
			const float inv_max_mag = 1.0f / s->maxMag();

			for (unsigned int i = 0; i < width(); i++){
				for (unsigned int j = 0; j < height(); j++){
					const vec2f pos = pixel_grid.pos(i,j);
					const float col_par = 0.5f * ((*s)(pos) * inv_max_mag + 1.0f);

					const QRgb value = qRgb(255.0f * col_par, 255.0f * (1.0f - col_par), 255.0f * (1.0f - col_par));
					map.setPixel(i, j, value);
				}
			}

			painter.drawImage(QRect(0, 0, width(), height()), map, QRect(0, 0, width(), height()));


			for (int i = 0; i < RAND_POINT_COUNT; i++){
				const unsigned int nx = rand() % v->grid().size().x;
				const unsigned int ny = rand() % v->grid().size().y;


				const float len = 1.01f * v->grid().scale().mag();

				QPainterPath path;

				vec2f pos = v->grid().pos(nx, ny);
				vec2f dir = (*v)(nx, ny);
				
				vec2f pixel_pos = pixel_grid.idx(pos);
				path.moveTo(pixel_pos.x, pixel_pos.y);

				for (int t = 0; t < 350; t++){
					if ( (pos.x <= v->grid().min().x) || (pos.x >= v->grid().max().x) || (pos.y <= v->grid().min().y) || (pos.y >= v->grid().max().y) )
						break;

					dir = (*v)(pos);
					// dir.setnorm();
					pos += len * dir;

					pixel_pos = pixel_grid.idx(pos);
					path.lineTo(pixel_pos.x, pixel_pos.y);
				}

				painter.setBrush(Qt::NoBrush);
				painter.drawPath(path);


				QPainterPath arrow_path;
				dir.setnorm();
				const float par = 4.0f;

				arrow_path.moveTo(pixel_pos.x, pixel_pos.y);
				arrow_path.lineTo(pixel_pos.x - 1.5f*par*dir.x - 0.5f*par*dir.y, pixel_pos.y - 1.5f*par*dir.y + 0.5f*par*dir.x);
				arrow_path.lineTo(pixel_pos.x - 1.5f*par*dir.x + 0.5f*par*dir.y, pixel_pos.y - 1.5f*par*dir.y - 0.5f*par*dir.x);
				arrow_path.closeSubpath();

				painter.setBrush(Qt::black);
				painter.drawPath(arrow_path);

			}

			painter.end();
		}

		void resizeEvent(QResizeEvent *event){
			pixel_grid.setSize(vec2u(this->width(), this->height()));
		}

	private:
		Grid2f pixel_grid;
		VecField2f *v;
		ScalarField2f *s;
		unsigned int *rand_num;
		unsigned int rand_num_size;



		void initRandNum(){
			if (rand_num != 0)
				delete[] rand_num;

			rand_num = new unsigned int[2*rand_num_size];

			for (unsigned int i = 0; i < 2*rand_num_size; i++){
				rand_num[i] = rand();
			}
		}
};


#endif // __RENDER_W_H__